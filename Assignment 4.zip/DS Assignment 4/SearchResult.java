import java.lang.*;
public class SearchResult implements Comparable<SearchResult>
{
	PageEntry p;
	float r;
	public SearchResult(PageEntry p1, float r1)
	{
		p=p1;
		r=r1;
	}
	public PageEntry getPageEntry()
	{
		return p;
	}
	public float getRelevance()
	{
		return r;
	}
	public int compareTo(SearchResult otherObject)
	{
		//Gives the ordering between the current object and the otherObject.
		if(this.getRelevance()==otherObject.getRelevance())
			return 0;
		else if(this.getRelevance()<=otherObject.getRelevance())
			return -1;
		else
			return 1;
	}

}