import java.util.*;
import java.io.*;
public class PageEntry{
	String PageName;
	PageIndex curr_index = new PageIndex();
	//String Page_data="";
	PageEntry(String pageIdentifier)
	{
		try 
		{
			PageName = pageIdentifier;
 			FileInputStream fstream = new FileInputStream(PageName);
 			Scanner s = new Scanner (fstream);
 			int counter=0;
 			int truecounter=0;
 			//int low_end=0;
 			while(s.hasNextLine())
 			{
 				String p=s.nextLine();
 				int i=0;
 				p=p.toLowerCase();
 				int j=0;
 				//int word_count;
 				while(i<p.length())
 				{
 					String point="";
 					j=i;
 					for(i=j; i<p.length(); i++)
 					{
 						if(p.charAt(i)==' '|| p.charAt(i)=='{'||p.charAt(i)=='}'|| p.charAt(i)=='[' || p.charAt(i)==']'||p.charAt(i)=='<'||p.charAt(i)=='>'||p.charAt(i)=='='||p.charAt(i)=='('||p.charAt(i)==')'||p.charAt(i)=='.'||p.charAt(i)==','||p.charAt(i)==';'||p.charAt(i)=='\''|| p.charAt(i)=='"'||p.charAt(i)=='?'||p.charAt(i)=='#'||p.charAt(i)=='!'||p.charAt(i)=='-'||p.charAt(i)==':')
 						{
 							break;
 						}
 						point+=Character.toString(p.charAt(i));
 					}
 					while(i<p.length()&&(p.charAt(i)==' '|| p.charAt(i)=='{' || p.charAt(i)=='}' || p.charAt(i)=='[' || p.charAt(i)==']'||p.charAt(i)=='<'||p.charAt(i)=='>'||p.charAt(i)=='='||p.charAt(i)=='('||p.charAt(i)==')'||p.charAt(i)=='.'||p.charAt(i)==','||p.charAt(i)==';'||p.charAt(i)=='\''|| p.charAt(i)=='"'||p.charAt(i)=='?'||p.charAt(i)=='#'||p.charAt(i)=='!'||p.charAt(i)=='-'||p.charAt(i)==':'))
 					{	
 						i++;
 					}
 					counter++;
 					switch (point)
					{
 						case "a":
	 					case "an":
 						case "the":
 						case "they":
 						case "these":
 						case "this":
 						case "for":
 						case "is":
 						case "are":
 						case "was":
 						case "of":
 						case "or":
 						case "and":
 						case "does":
 						case "will":
 						case "whose":
 						case "":
 							break;
 						case "stacks":
 							truecounter++;
 							Position p1=new Position(this , counter, truecounter);
 							this.curr_index.addPositionForWord("stack", p1);
 							break;
 						case "structures":
 							truecounter++;
 							Position p2=new Position(this , counter, truecounter);
 							this.curr_index.addPositionForWord("structure", p2);
 							break;
 						case "applications":
 							truecounter++;
 							Position p3=new Position(this , counter, truecounter);
 							this.curr_index.addPositionForWord("application", p3);
 							break;
 						default:
 							truecounter++;
 							Position p4=new Position(this , counter, truecounter);
 							this.curr_index.addPositionForWord(point, p4);
 							break;
 					}
 				}
 			}
 		}
 		catch(FileNotFoundException e)
 		{
 			System.out.println("File not found");
 		}
	}
	public PageIndex getPageIndex()
	{
		return this.curr_index;
	}
	public String getPageName()
	{
		return this.PageName;
	}
	public float getTermFrequency(String word)
	{
		int sum=0;
		int num=0;
		MyLinkedList<WordEntry> Page_word = curr_index.getWordEntries();
		for(int i=0; i<Page_word.size(); i++)
		{
			WordEntry pointer=Page_word.elementAt(i);
			sum+=pointer.getTermFrequency();
			if(word.equals(pointer.str_value()))
				num=pointer.getTermFrequency();
		}
		return ((float)num/(float)sum);		
	}
	float getTermFrequencyofPhrase(String str[])
	{
		int sum=0;
		MyLinkedList<WordEntry> Page_word = curr_index.getWordEntries();
		MyLinkedList<WordEntry> checker = curr_index.getWordEntries();
		for(int i=0; i<Page_word.size(); i++)
		{
			WordEntry pointer=Page_word.elementAt(i);
			sum+=pointer.getTermFrequency();
		}
		WordEntry parse=null;
		int count=0;;
		int j;
		for(j=0; j<checker.size(); j++)
		{
			parse=checker.elementAt(j);
			if(parse.str_value().equals(str[0]))
				break;
		}
		if(j==checker.size())
			return 0;
		for(j=0; j<parse.getAllPositionsForThisWord().size(); j++)
		{
			Position pos=parse.getAllPositionsForThisWord().elementAt(j);
			int k=1;
			WordEntry parse1=null;
			while(k<str.length)
			{
				parse1=null;
				for(int l=0; l<checker.size(); l++)
				{
					parse1=checker.elementAt(l);
					if(parse1.str_value().equals(str[k]))
						break;
				}
				if(parse1.str_value().equals(str[k])==false)
						break;
				if(parse1.loc_tree().xplusfind(pos.getTrueIndex())==null)
					break;
				if(parse1.loc_tree().xplusfind(pos.getTrueIndex()).getTrueIndex()!= (pos.getTrueIndex()+1))
					break;
				k++;
				pos=parse1.loc_tree().xplusfind(pos.getTrueIndex());
			}
			if(k==str.length)
			{
				count++;
			}
		}
		sum=sum-count*(str.length-1);
		return (float)count/(float) sum;
	}
}