public class AVLTree
{
	private static class node
	{
		Position data;
		node left;
		node right;
		int height;
		public node(Position e )
		{
			data = e;
			height=0;
		}
		public Position getElement()
		{
			return data;
		}
		public node getleftchild()
		{
			return left;
		}
		public void setleft(node n)
		{
			left = n;
		}
		public void setright(node n)
		{
			right = n;
		}
		private int height(node t)
     	{
        	return t == null?-1:t.height;
     	}
	}
	node root;
	int size;
	AVLTree(node a)
	{
		root=a;
		if(a==null)
			size=0;
		else 
		size=1; 
	}
	private int height(node t )
    {
        return t == null ? -1 : t.height;
   	}
	public Position getroot()
	{
		return root.data;
	}
	int size()
	{
		return size;
	}
	int max(int a, int b)
	{ 
        return a>b?a:b; 
    }
    boolean isMember(node point, Position find)
    {
    	if(point==null)
    		return false;
    	if(root.getElement()==find)
    		return true;
    	if(root.getElement().getWordIndex()>find.getWordIndex())
    		return isMember(point.left, find);
    	else
    		return isMember(point.right, find);
    }
    node rightRotate(node y)
    { 
        node x = y.left; 
        node T2 = x.right; 
  
        // Perform rotation 
        x.right = y; 
        y.left = T2; 
  
        // Update heights 
        y.height = max(height(y.left), height(y.right)) + 1; 
        x.height = max(height(x.left), height(x.right)) + 1; 
  
        // Return new root 
        return x; 
    } 
    node leftRotate(node x) { 
        node y = x.right; 
        node T2 = y.left; 
  
        // Perform rotation 
        y.left = x; 
        x.right = T2; 
  
        //  Update heights 
        x.height = max(height(x.left), height(x.right)) + 1; 
        y.height = max(height(y.left), height(y.right)) + 1; 
  
        // Return new root 
        return y; 
    }
    int getBalance(node N) { 
        if(N == null) 
            return 0;
        return height(N.left) - height(N.right); 
    } 

     public void insert(Position new_node)
     {
     	 size++;
         root = insert(root, new_node);
     }
     node insert(node node, Position new_node) { 
  
        /* 1.  Perform the normal BST insertion */
        if(node==null) 
            return (new node(new_node)); 
  
        if(new_node.getWordIndex() < node.getElement().getWordIndex()) 
            node.left = insert(node.left, new_node); 
        else if (new_node.getWordIndex() > node.getElement().getWordIndex()) 
            node.right = insert(node.right, new_node); 
        else // Duplicate keys not allowed 
            return node; 
  
        /* 2. Update height of this ancestor node */
        node.height = 1 + max(height(node.left), height(node.right)); 
  
        /* 3. Get the balance factor of this ancestor 
              node to check whether this node became 
              unbalanced */
        int balance = getBalance(node); 
  
        // If this node becomes unbalanced, then there 
        // are 4 cases Left Left Case 
        if (balance > 1 && (new_node.getWordIndex() < node.left.getElement().getWordIndex())) 
            return rightRotate(node); 
  
        // Right Right Case 
        if (balance < -1 && new_node.getWordIndex() > node.right.getElement().getWordIndex()) 
            return leftRotate(node); 
  
        // Left Right Case 
        if (balance > 1 && new_node.getWordIndex() > node.left.getElement().getWordIndex()) { 
            node.left = leftRotate(node.left); 
            return rightRotate(node); 
        } 
  
        // Right Left Case 
        if (balance < -1 && new_node.getWordIndex() < node.right.getElement().getWordIndex()) { 
            node.right = rightRotate(node.right); 
            return leftRotate(node); 
        } 
  
        /* return the (unchanged) node pointer */
        return node; 
    } 
  
    // A utility function to print preorder traversal 
    // of the tree. 
    // The function also prints height of every node 
    void inOrder(node node)
    { 
        if(node != null) 
        { 
        	inOrder(node.left);
            System.out.print(node.getElement().getWordIndex() + ", ");  
            inOrder(node.right); 
        } 
    }
    Position xplusfind(int pos)
    {
    	node xplus=null;
    	node point =root;
        node xplus2=null;
    	while(point!=null)
    	{
   			if(pos<point.getElement().getTrueIndex())
   			{
   				xplus=point;
   				point=point.left;
   			}
            else if(pos==point.getElement().getTrueIndex())
            {
                break;
            }
    		else
   				point=point.right;
   		}
        if(point!=null && point.getright!=null)
        {
            point=point.right;
            while(point!=null)
            {
                xplus2=point;
                point=point.left;
            }
        }
        else
            return xplus.getElement();
        if(xplus.getElement().getTrueIndex()<xplus2.getElement().getTrueIndex())
            return xplus.getElement();
        else
            return xplus2.getElement();
    }
}