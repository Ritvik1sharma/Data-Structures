public class Position
{
	private PageEntry page;
	private int wordposition;
	int trueindex;
	Position(PageEntry p, int wordIndex , int truecounter)
	{
		page=p;
		wordposition=wordIndex;
		trueindex=truecounter;
	}
	public PageEntry getPageEntry()
	{
		return page;
	}
	public int getWordIndex()
	{
		return wordposition;
	}
	public int getTrueIndex()
	{
		return trueindex;
	}	
}
