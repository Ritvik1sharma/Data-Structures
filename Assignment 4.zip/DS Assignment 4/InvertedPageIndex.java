import java.lang.*;
public class InvertedPageIndex
{
	Myset<PageEntry> page_index=new Myset<PageEntry>();
	MyHashTable Table = new MyHashTable();
	public void addPage(PageEntry p)
	{
		WordEntry point;
		for(int i=0; i<p.getPageIndex().getWordEntries().size(); i++)
		{
			point=p.getPageIndex().getWordEntries().elementAt(i);

			Table.addPositionsForWord(point);
		}
		page_index.addElement(p);
		return;
	}
	public Myset<PageEntry> getPageIndex()
	{
		return page_index;
	}
	public Myset<PageEntry> getPagesWhichContainWord(String str)
	{
		Myset<PageEntry> Pages_with_word = new Myset<PageEntry>();
		WordEntry word=Table.getWordEntry(str);
		
		if(word==null)
		{
			return Pages_with_word;
		}
		for(int i=0; i<word.getAllPositionsForThisWord().size(); i++)
		{
			if(Pages_with_word.isMember(word.getAllPositionsForThisWord().elementAt(i).getPageEntry())==false)
			{
				Pages_with_word.addElement(word.getAllPositionsForThisWord().elementAt(i).getPageEntry());
			}
		}
		return Pages_with_word;
	}
	float getRelevanceOfPage(String str[ ], boolean doTheseWordsRepresentAPhrase, PageEntry page)
	{
		if(doTheseWordsRepresentAPhrase==true)
		{
				Myset<PageEntry> containPhrase=this.getPagesWhichContainPhrase(str);
				float idf_true= (float) Math.log(((double)page_index.size())/((double)containPhrase.size()));
				return idf_true*(page.getTermFrequencyofPhrase(str));
		}
		else
		{
			float relevance=0;
				for(int i=0; i<str.length; i++)
				{
					float termfreq=page.getTermFrequency(str[i]);
					float idf_false=(float) Math.log(((double)page_index.size())/((double)this.getPagesWhichContainWord(str[i]).size()));
					relevance+=(float) (termfreq*idf_false);
				}
				return relevance;
		}			
	}
	Myset<PageEntry> getPagesWhichContainPhrase(String str[])
	{
		Myset<PageEntry> ans=new Myset<>();
		for(int i=0; i<page_index.size(); i++)
		{
			PageEntry check=page_index.elementAt(i);
			WordEntry parse=null;
			MyLinkedList<WordEntry> checker=check.getPageIndex().getWordEntries();
			int j=0;
			for(j=0; j<checker.size(); j++)
			{
				parse=checker.elementAt(j);
				if(parse.str_value().equals(str[0]))
					break;
			}
			if(j==checker.size())
			{
				continue;
			}
			for( j=0; j<parse.getAllPositionsForThisWord().size(); j++)
			{
				Position pos=parse.getAllPositionsForThisWord().elementAt(j);
				int k=1;
				WordEntry parse1=null;
				while(k<str.length)
				{
					int l;					
					for( l=0; l<checker.size(); l++)
					{
						parse1=checker.elementAt(l);
						if(parse1.str_value().equals(str[k]))
							break;
					}
					if(parse1.str_value().equals(str[k])==false)
						break;
					if(parse1.loc_tree().xplusfind(pos.getTrueIndex())==null)
					{
						break;
					}
					if(parse1.loc_tree().xplusfind(pos.getTrueIndex()).getTrueIndex()!= (pos.getTrueIndex()+1))
					{	
						break;
					}
					k++;
					pos=parse1.loc_tree().xplusfind(pos.getTrueIndex());
				}
				if(k==str.length)
				{
					ans.addElement(check);
					break;
				}
			}
		}
		return ans;
	}
}