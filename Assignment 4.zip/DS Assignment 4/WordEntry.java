public class WordEntry
{
	MyLinkedList<Position> location_prime;
	AVLTree location;
	String str_value;
	WordEntry(String entry)
	{
		str_value=entry;
		Position point= null;
		location = new AVLTree(null);
		location_prime=new MyLinkedList<Position>();
	}
	public String str_value()
	{
		return str_value;
	}
	public void addPosition(Position position)
	{
		location_prime.addLast(position);
		location.insert(position);
	}
	public void addPositions(MyLinkedList<Position> positions)
	{
		
		location_prime=location_prime.union(positions);
		for(int i=0; i<positions.size(); i++)
		{
			location.insert(positions.elementAt(i));
		}
	}
	public MyLinkedList<Position> getAllPositionsForThisWord()
	{
		return location_prime;
	}
	public AVLTree loc_tree()
	{
		return location;
	}
	public int getTermFrequency()
	{
		return location_prime.size();
	}
}
