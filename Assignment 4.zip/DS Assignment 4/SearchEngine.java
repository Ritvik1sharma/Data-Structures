import java.util.*;
public class SearchEngine
{
	InvertedPageIndex Inverted_Page_Index;
	SearchEngine()
	{
	  	Inverted_Page_Index =new InvertedPageIndex();
	}
	public void performAction(String actionMessage)
	{
		if(actionMessage.charAt(0)=='a')
		{
			String ans=actionMessage.substring(8);
			PageEntry p = new PageEntry(ans);
			Inverted_Page_Index.addPage(p);
		}
		if(actionMessage.charAt(0)=='q')
		{
			if(actionMessage.charAt(14)=='W')
			{
				if(actionMessage.charAt(26)=='W')
				{
					String ans=actionMessage.substring(31);
					String ans_check=ans.toLowerCase();
					switch(ans_check)
					{
						case("stacks"):
							ans_check="stack";
							break;
						case("applications"):
							ans_check="application";
							break;
						case("structures"):
							ans_check="structure";
							break;
					}
					Myset<PageEntry> ans_pages;
					ans_pages=Inverted_Page_Index.getPagesWhichContainWord(ans_check);
					if(ans_pages.size()==0)
					{
						System.out.println("No webpage contains word " + ans);
						return;
					}
					Myset<SearchResult> newlist= new Myset<>();
					for(int i=0; i< ans_pages.size(); i++)
					{
						String[] str1=new String[1];
						str1[0]=ans_check;
						SearchResult newresult= new SearchResult(ans_pages.elementAt(i), Inverted_Page_Index.getRelevanceOfPage(str1 ,false, ans_pages.elementAt(i) ) );
						newlist.addElement(newresult);
					}
					MySort<SearchResult> a = new MySort<>();
					ArrayList<SearchResult> MySortedlist= a.sortThisList(newlist);
					SearchResult pointer=MySortedlist.get(0);
					int i=0;
					for(i=0; i<(MySortedlist.size()-1); i++)
					{
						pointer=MySortedlist.get(i);
						System.out.print(pointer.getPageEntry().getPageName()+", ");
					}
					 pointer=MySortedlist.get(i);
					System.out.println(pointer.getPageEntry().getPageName());
				}
				if(actionMessage.charAt(26)=='A')
				{
					if(actionMessage.charAt(27)=='l')
					{
						int count=1;
						for(int i=35; i<actionMessage.length(); i++)
						{
							while(i<actionMessage.length())
							{
								if(actionMessage.charAt(i)==' ')
								{
									count++;
									break;
								}
								i++;
							}
						}
						String[] str=new String[count];
						for(int i=35, k=0; i<actionMessage.length(); i++)
						{
							String word=""; 
							while(i<actionMessage.length())
							{
								if(actionMessage.charAt(i)==' ')
								{
									word=word.toLowerCase();
									switch(word)
									{
										case("stacks"):
											word="stack";
											break;
										case("applications"):
											word="application";
											break;
										case("structures"):
											word="structure";
											break;
									}
									str[k]=word;
									k++;
									while(i<actionMessage.length() && actionMessage.charAt(i)==' ')
										i++;
									i--;
									break;
								}
								word+=actionMessage.charAt(i);
								i++;
							}
							if(i==actionMessage.length())
							{
								word=word.toLowerCase();
								switch(word)
									{
										case("stacks"):
											word="stack";
											break;
										case("applications"):
											word="application";
											break;
										case("structures"):
											word="structure";
											break;
									}
								str[k]=word;
								k++;
							}
						}
						Myset<PageEntry> ans_words=new Myset<>();
						ans_words=this.Inverted_Page_Index.getPagesWhichContainWord(str[0]);
						if(ans_words.size()==0)
						{
							System.out.print("No webpage contains all word ");
							for(int i=0; i<str.length; i++)
							{
								System.out.print(str[i]+" ");
							}
							System.out.println();
							return;
						}
						for(int k=1; k<str.length; k++)
						{
							ans_words=ans_words.intersection(this.Inverted_Page_Index.getPagesWhichContainWord(str[k]));
						}
						if(ans_words.size()==0)
						{
							System.out.print("No webpage contains all word ");
							for(int i=0; i<str.length; i++)
							{
								System.out.print(str[i]+" ");
							}
							System.out.println(actionMessage.substring(35));
							return;
						}
						Myset<SearchResult> newlist= new Myset<>();
						for(int i=0; i< ans_words.size(); i++)
						{
							SearchResult newresult= new SearchResult(ans_words.elementAt(i), Inverted_Page_Index.getRelevanceOfPage(str ,false, ans_words.elementAt(i) ) );
							newlist.addElement(newresult);
						}
						MySort a = new MySort();
						ArrayList<SearchResult> MySortedlist= a.sortThisList(newlist);
						int i;
						for(i=0; i<(MySortedlist.size()-1); i++)
						{
							SearchResult pointer=MySortedlist.get(i);
							System.out.print(pointer.getPageEntry().getPageName()+" "/*+pointer.getRelevance()+", "*/);
						}
						SearchResult pointer=MySortedlist.get(i);
						System.out.println(pointer.getPageEntry().getPageName());
					}

					if(actionMessage.charAt(27)=='n')
					{
						int count=1;
						for(int i=42; i<actionMessage.length(); i++)
						{
							while(i<actionMessage.length())
							{
								if(actionMessage.charAt(i)==' ')
								{
									count++;
									break;
								}
								i++;
							}
						}
						String[] str=new String[count];
						int k=0;
						int i;
						for(i=42; i<actionMessage.length(); i++)
						{
							String word="";
							while(i<actionMessage.length())
							{
								if(actionMessage.charAt(i)==' ')
								{
									word=word.toLowerCase();
									switch(word)
									{
										case("stacks"):
											word="stack";
											break;
										case("applications"):
											word="application";
											break;
										case("structures"):
											word="structure";
											break;
									}
									str[k]=word;
									k++;
									while(i<actionMessage.length() && actionMessage.charAt(i)==' ')
										i++;
									i--;
									break;
								}
								word+=actionMessage.charAt(i);
								i++;
							}
							if(i==actionMessage.length())
							{
								word=word.toLowerCase();
								switch(word)
									{
										case("stacks"):
											word="stack";
											break;
										case("applications"):
											word="application";
											break;
										case("structures"):
											word="structure";
											break;
									}
								str[k]=word;
								k++;
							}
						}
						Myset<PageEntry> ans_words=new Myset<>();
						ans_words=this.Inverted_Page_Index.getPagesWhichContainWord(str[0]);
						for(k=1; k<str.length; k++)
						{
							ans_words=ans_words.union(this.Inverted_Page_Index.getPagesWhichContainWord(str[k]));
						}
						if(ans_words.size()==0)
						{
							System.out.print("No webpage contains any word ");
							System.out.println(actionMessage.substring(42));
							return;
						}
						Myset<SearchResult> newlist= new Myset<>();
						for(i=0; i<ans_words.size(); i++)
						{
							SearchResult newresult= new SearchResult(ans_words.elementAt(i), Inverted_Page_Index.getRelevanceOfPage(str ,false, ans_words.elementAt(i) ) );
							newlist.addElement(newresult);
						}
						MySort a=new MySort();
						ArrayList<SearchResult> MySortedlist=a.sortThisList(newlist);
						for(i=0; i<(MySortedlist.size()-1); i++)
						{
							SearchResult pointer=MySortedlist.get(i);
							System.out.print(pointer.getPageEntry().getPageName() +" "/*+ pointer.getRelevance()+", "*/);
						}
						SearchResult pointer=MySortedlist.get(i);
						System.out.println(pointer.getPageEntry().getPageName());
					}

				}
				if(actionMessage.charAt(26)=='P')
				{
						int count=1;
						int k=0;
						int i;
						for(i=35; i<actionMessage.length(); i++)
						{
							while(i<actionMessage.length())
							{
								if(actionMessage.charAt(i)==' ')
								{
									count++;
									break;
								}
								i++;
							}
						}
						String[] str=new String[count];
						for(i=33, k=0; i<actionMessage.length(); i++)
						{
							String word=""; 
							while(i<actionMessage.length())
							{
								if(actionMessage.charAt(i)==' ')
								{
									word=word.toLowerCase();
									switch(word)
									{
										case("stacks"):
											word="stack";
											break;
										case("applications"):
											word="application";
											break;
										case("structures"):
											word="structure";
											break;
									}
									str[k]=word;
									k++;
									while(i<actionMessage.length() && actionMessage.charAt(i)==' ')
										i++;
									i--;
									break;
								}
								word+=actionMessage.charAt(i);
								i++;
							}
							if(i==actionMessage.length())
							{
								word=word.toLowerCase();
								switch(word)
									{
										case("stacks"):
											word="stack";
											break;
										case("applications"):
											word="application";
											break;
										case("structures"):
											word="structure";
											break;
									}
								str[k]=word;
								k++;
							}
						}
						Myset<PageEntry> ans_words=this.Inverted_Page_Index.getPagesWhichContainPhrase(str);
						if(ans_words.size()==0)
						{
							System.out.print("No webpage contains phrase ");
							System.out.println(actionMessage.substring(33));
							return;
						}
						Myset<SearchResult> newlist= new Myset<>();
						for(i=0; i< ans_words.size(); i++)
						{
							SearchResult newresult= new SearchResult(ans_words.elementAt(i), Inverted_Page_Index.getRelevanceOfPage(str , true , ans_words.elementAt(i) ) );
							newlist.addElement(newresult);
						}
						MySort a=new MySort();
						ArrayList<SearchResult> MySortedlist= a.sortThisList(newlist);
						for(i=0; i<(MySortedlist.size()-1); i++)
						{
							SearchResult pointer=MySortedlist.get(i);
							System.out.print(pointer.getPageEntry().getPageName()+",  " /*+ pointer.getRelevance()+", "*/);
						}
						SearchResult pointer=MySortedlist.get(i);
						System.out.println(pointer.getPageEntry().getPageName());
				}
			}
			if(actionMessage.charAt(14)=='i')
			{
				int i;
				for(i=32; i<actionMessage.length(); i++)
				{
					if(actionMessage.charAt(i)==' ')
					{
						break;
					}
				}
				String word=actionMessage.substring(32, i);
				String word_prime=word.toLowerCase();
				switch(word_prime)
				{
					case("stacks"):
						word_prime="stack";
						break;
					case("applications"):
						word_prime="application";
						break;
					case("structures"):
						word_prime="structure";
						break;
				}
				String document=actionMessage.substring(i+1);
				Myset<PageEntry> page_index=Inverted_Page_Index.getPageIndex();
				PageEntry pointer=null;
				for(i=0; i<page_index.size(); i++)
				{
					pointer=page_index.elementAt(i);
					if(document.equals(pointer.getPageName()))
						break;
				}
				if(i==page_index.size())
				{
					System.out.println("No webpage with name "+document);
					return;
				}
				WordEntry checker;
				MyLinkedList<Position> ans=new MyLinkedList<>();
				for(i=0; i<pointer.getPageIndex().getWordEntries().size(); i++)
				{
					checker=pointer.getPageIndex().getWordEntries().elementAt(i);
					if(word_prime.equals(checker.str_value()))
					{
						ans=checker.getAllPositionsForThisWord();
						break;
					}
				}
				if(ans.size()==0)
				{
					System.out.println(document+" does not contain word "+word);
					return;
				}
				for(i=0; i<(ans.size()-1); i++)
				{
					System.out.print(ans.elementAt(i).getWordIndex()+", ");
				}
				System.out.println(ans.elementAt(i).getWordIndex());
			}
		}
	}
}