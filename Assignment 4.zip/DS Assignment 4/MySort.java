import java.util.*;
public class MySort<T extends Comparable>
{
	ArrayList<T> sortThisList(Myset<T> listOfSortableEntries)
	{
		ArrayList<T> ans=new ArrayList<>();
		if(listOfSortableEntries.size()==0)
			return ans;
		else if(listOfSortableEntries.size()==1)
		{
			ans.add(listOfSortableEntries.elementAt(0));
			return ans;
		}
		for(int j=0; j<listOfSortableEntries.size(); j++)
		{
			int i=0;
			while(i<ans.size() && ans.get(i).compareTo(listOfSortableEntries.elementAt(j))>0)
				i++;
			if(i==ans.size())
				ans.add(listOfSortableEntries.elementAt(j));
			else
				ans.add(i , listOfSortableEntries.elementAt(j));
		}
		return ans;
	}
}