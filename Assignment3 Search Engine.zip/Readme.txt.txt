Plese note the actions file and the websites along with the Java code files need to be in the same directory to run together.
Actions file is a simple example of operations being performed on the search engine for serching phrases from webpages and fetching output pages based on relevance.
