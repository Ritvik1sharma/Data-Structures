public class Myset<E>
{
	MyLinkedList<E> objects = new MyLinkedList<E>();
	public void addElement(E e)
	{
		objects.addLast(e);
	}
	public Myset<E> union(Myset<E> otherset)
	{
		this.objects=this.objects.union(otherset.objects);
		return this;
	}
	public Myset<E> intersection(Myset<E> otherset)
	{
		this.objects=this.objects.intersection(otherset.objects);
		return this;
	}
	public boolean isMember(E e)
	{
		return this.objects.isMember(e);
	}
	public int size()
	{
		return this.objects.size();
	}
	public E elementAt(int i)
	{
		return this.objects.elementAt(i);
	}
}
