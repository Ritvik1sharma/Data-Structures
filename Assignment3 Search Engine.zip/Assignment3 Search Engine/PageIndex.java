import java.util.*;
import java.io.*;
public class PageIndex
{
	MyLinkedList<WordEntry> Page_word=new MyLinkedList<>();
	public void addPositionForWord(String str, Position p)
	{
		for(int i=0; i<Page_word.size(); i++)
		{
			if(str.equals(Page_word.elementAt(i).str_value()))
			{
				Page_word.elementAt(i).addPosition(p);
				return;
			}
		}
		WordEntry new_word = new WordEntry(str);
		new_word.addPosition(p);
		Page_word.addLast(new_word);
		return;
	}
	public MyLinkedList<WordEntry> getWordEntries()
	{
		return Page_word;
	}
	public float getTermFrequency(String word)
	{
		int sum=0;
		int num=0;
		for(int i=0; i<Page_word.size(); i++)
		{
			WordEntry pointer=Page_word.elementAt(i);
			sum+=pointer.getTermFrequency();
			if(word.equals(pointer.str_value()))
				num=pointer.getTermFrequency();
		}
		return (num/sum);		
	}
}