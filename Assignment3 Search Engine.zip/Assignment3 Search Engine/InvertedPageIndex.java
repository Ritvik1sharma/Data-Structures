public class InvertedPageIndex
{
	Myset<PageEntry> page_index=new Myset<PageEntry>();
	MyHashTable Table = new MyHashTable();
	public void addPage(PageEntry p)
	{
		WordEntry point;
		for(int i=0; i<p.getPageIndex().getWordEntries().size(); i++)
		{
			point=p.getPageIndex().getWordEntries().elementAt(i);

			Table.addPositionsForWord(point);
		}
		page_index.addElement(p);
		return;
	}
	public Myset<PageEntry> getPageIndex()
	{
		return page_index;
	}
	public Myset<PageEntry> getPagesWhichContainWord(String str)
	{
		Myset<PageEntry> Pages_with_word = new Myset<PageEntry>();
		PageEntry page;
		int i;		
		for(i=0; i<page_index.size(); i++)
		{
			page=page_index.elementAt(i);
			for(int j=0; j<page.getPageIndex().getWordEntries().size(); j++)
			{
				WordEntry word=page.getPageIndex().getWordEntries().elementAt(j);
				if(str.equals(word.str_value()))
				{
					Pages_with_word.addElement(page);
					break;
				}
			}
		}
		return Pages_with_word;
	}
}