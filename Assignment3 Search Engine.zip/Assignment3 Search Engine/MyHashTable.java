class Hashnode
{
	WordEntry data;
	Hashnode next;
	public Hashnode(WordEntry e, Hashnode n)
	{
		data = e;
		next = n;
	}
	public WordEntry getElement()
	{
		return data;
	}
	public Hashnode getNext()
	{
		return next;
	}
	public void setNext(Hashnode n)
	{
		next = n;
	}
	public void setElement(WordEntry w)
	{
		data=w;
		return;
	}
}
public class MyHashTable
{
	Hashnode[] hashmap = new Hashnode[1499];
	private int getHashIndex(String str)
	{
		int i=0;
		int sum=1;
		if(str.length()==0)
			return 0;
		for(i=0; i<str.length(); i++)
		{
			if(str.charAt(i)<97||str.charAt(i)>122)
			{
				continue;
			}
			sum=sum*(str.charAt(i)-96);
		}
		if(sum%1499<0)
			return (sum%1499)*(-1);
		return (sum%1499);		
	}
	public void addPositionsForWord(WordEntry w)
	{
		int i=getHashIndex(w.str_value());
		Hashnode checker = hashmap[i];
		if(checker==null)
		{
			hashmap[i]=new Hashnode(w, null);
			return;
		}
		while(checker.next!=null)
		{
			if((w.str_value()).equals((checker.getElement().str_value())))
			{
				WordEntry ans_check;
				ans_check=checker.getElement();
				ans_check.addPositions(w.getAllPositionsForThisWord());
				checker.setElement(ans_check);
				return;
			}
			checker=checker.getNext();
		}
		Hashnode tail=new Hashnode(w, null);
		checker.next=tail;
		return;		
	}
}