import java.util.*;
import java.io.*;
public class PageEntry{
	String PageName;
	PageIndex curr_index = new PageIndex();
	PageEntry(String pageIdentifier)
	{
		try 
		{
			PageName = pageIdentifier;
 			FileInputStream fstream = new FileInputStream(PageName);
 			Scanner s = new Scanner (fstream);
 			int counter=0;
 			int low_end=0;
 			while(s.hasNextLine())
 			{
 				String p=s.nextLine();
 				int i=0;
 				p=p.toLowerCase();
 				int j=0;
 				while(i<p.length())
 				{
 					String point="";
 					j=i;
 					for(i=j; i<p.length(); i++)
 					{
 						if(p.charAt(i)==' '|| p.charAt(i)=='{'||p.charAt(i)=='}'|| p.charAt(i)=='[' || p.charAt(i)==']'||p.charAt(i)=='<'||p.charAt(i)=='>'||p.charAt(i)=='='||p.charAt(i)=='('||p.charAt(i)==')'||p.charAt(i)=='.'||p.charAt(i)==','||p.charAt(i)==';'||p.charAt(i)=='\''|| p.charAt(i)=='"'||p.charAt(i)=='?'||p.charAt(i)=='#'||p.charAt(i)=='!'||p.charAt(i)=='-'||p.charAt(i)==':')
 						{
 							break;
 						}
 						point+=Character.toString(p.charAt(i));
 					}
 					while(i<p.length()&&(p.charAt(i)==' '|| p.charAt(i)=='{' || p.charAt(i)=='}' || p.charAt(i)=='[' || p.charAt(i)==']'||p.charAt(i)=='<'||p.charAt(i)=='>'||p.charAt(i)=='='||p.charAt(i)=='('||p.charAt(i)==')'||p.charAt(i)=='.'||p.charAt(i)==','||p.charAt(i)==';'||p.charAt(i)=='\''|| p.charAt(i)=='"'||p.charAt(i)=='?'||p.charAt(i)=='#'||p.charAt(i)=='!'||p.charAt(i)=='-'||p.charAt(i)==':'))
 					{	
 						i++;
 					}
 					counter=j+low_end;
 					switch (point)
					{
 						case "a":
	 					case "an":
 						case "the":
 						case "they":
 						case "these":
 						case "this":
 						case "for":
 						case "is":
 						case "are":
 						case "was":
 						case "of":
 						case "or":
 						case "and":
 						case "does":
 						case "will":
 						case "whose":
 						case "":
 							break;
 						case "stacks":
 							Position p1=new Position(this , counter);
 							this.curr_index.addPositionForWord("stack", p1);
 							break;
 						case "structures":
 							Position p2=new Position(this , counter);
 							this.curr_index.addPositionForWord("structures", p2);
 							break;
 						case "applications":
 							Position p3=new Position(this , counter);
 							this.curr_index.addPositionForWord("application", p3);
 							break;
 						default:
 							Position p4=new Position(this , counter);
 							this.curr_index.addPositionForWord(point, p4);
 							break;
 					}
 				}
 				low_end+=p.length();
 			}
 		}
 		catch(FileNotFoundException e)
 		{
 			System.out.println("File not found");
 		}
	}
	public PageIndex getPageIndex()
	{
		return this.curr_index;
	}
	public String getPageName()
	{
		return this.PageName;
	}
}

