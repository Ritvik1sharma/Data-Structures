public class SearchEngine
{
	InvertedPageIndex Inverted_Page_Index;
	SearchEngine()
	{
	  	Inverted_Page_Index =new InvertedPageIndex();
	}

	public void performAction(String actionMessage)
	{
		if(actionMessage.charAt(0)=='a')
		{
			String ans=actionMessage.substring(8);
			PageEntry p = new PageEntry(ans);
			Inverted_Page_Index.addPage(p);
		}
		if(actionMessage.charAt(0)=='q')
		{
			if(actionMessage.charAt(14)=='W')
			{
				String ans=actionMessage.substring(31);
				String ans_check=ans.toLowerCase();
				Myset<PageEntry> ans_pages;
				ans_pages=Inverted_Page_Index.getPagesWhichContainWord(ans_check);
				if(ans_pages.size()==0)
				{
					System.out.println("No webpage contains word " + ans);
					return;
				}
				int i=0;
				for(i=0; i<(ans_pages.size()-1); i++)
				{
					PageEntry pointer=ans_pages.elementAt(i);
					System.out.print(pointer.getPageName()+", ");
				}
				PageEntry pointer=ans_pages.elementAt(i);
				System.out.println(pointer.getPageName());
			}
			if(actionMessage.charAt(14)=='i')
			{
				int i;
				//System.out.println(actionMessage);
				for(i=32; i<actionMessage.length(); i++)
				{
					if(actionMessage.charAt(i)==' ')
					{
						break;
					}
				}
				String word=actionMessage.substring(32, i);
				String word_prime=word.toLowerCase();
				String document=actionMessage.substring(i+1);
				Myset<PageEntry> page_index=Inverted_Page_Index.getPageIndex();
				PageEntry pointer=null;
				for(i=0; i<page_index.size(); i++)
				{
					pointer=page_index.elementAt(i);
					if(document.equals(pointer.getPageName()))
						break;
				}
				WordEntry checker;
				MyLinkedList<Position> ans=null;
				for(i=0; i<pointer.getPageIndex().getWordEntries().size(); i++)
				{
					checker=pointer.getPageIndex().getWordEntries().elementAt(i);
					if(word_prime.equals(checker.str_value()))
					{
						ans=checker.getAllPositionsForThisWord();
						break;
					}
				}
				if(ans==null)
				{
					System.out.println(document+" does not contain word "+word);
					return;
				}
				for(i=0; i<(ans.size()-1); i++)
				{
					System.out.print(ans.elementAt(i).getWordIndex()+", ");
				}
				System.out.println(ans.elementAt(i).getWordIndex());
			}
		}
	}
}