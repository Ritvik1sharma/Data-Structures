public class WordEntry
{
	MyLinkedList<Position> location;
	String str_value;
	WordEntry(String entry)
	{
		str_value=entry;
		location = new MyLinkedList<Position>();
	}
	public String str_value()
	{
		return str_value;
	}
	public void addPosition(Position position)
	{
		location.addLast(position);
	}
	public void addPositions(MyLinkedList<Position> positions)
	{
		location=location.union(positions);
	}
	public MyLinkedList<Position> getAllPositionsForThisWord()
	{
		return location;
	}
	public int getTermFrequency()
	{
		return location.size();
	}
}
