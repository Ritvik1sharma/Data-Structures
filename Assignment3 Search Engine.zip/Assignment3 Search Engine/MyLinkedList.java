public class MyLinkedList<E>
{
	private static class Node<E>
	{
		private E element;
		private Node<E> next;
		public Node(E e, Node<E> n)
		{
			element = e;
			next = n;
		}
		public E getElement()
		{
			return element;
		}
		public Node <E> getNext()
		{
			return next;
		}
		public void setNext(Node<E> n)
		{
			next = n;
		}
	}
	private Node<E> head =null;
	private Node<E> tail =null;
	private int size = 0;
	public int size()
	{
		return size;
	}
	public boolean isEmpty()
	{
		if(size == 0)
			return true;
		return false;
	}
	public E first()
	{
		if(isEmpty())
			return null;
		return head.getElement();
	}
	public E last()
	{	
		if(isEmpty())
			return null;
		return tail.getElement();
	}
	public E elementAt(int i)
	{
		Node<E> pointer=this.gethead();
		while(i!=0)
		{
			pointer=pointer.getNext();
			i--;
		}
		return pointer.getElement();
	}
	public boolean isMember(E e)
	{
		Node<E> pointer;
		pointer=this.gethead();
		while(pointer!=null)
		{
			if(pointer.getElement()==e)
				return true;
			pointer=pointer.getNext();
		}
		return false;
	}
	public Node<E> gethead()
	{
		return head;
	}
	public void addFirst(E e)
	{
		head =new Node<>(e, head);
		if(size == 0)
			tail = head;
		size++;
	}
	public void addLast(E e)
	{
		Node<E> newest =new Node<>(e,null);
		if(isEmpty())
			head = newest;
		else tail.setNext(newest);
		tail = newest;
		size++;
	}
	public E removeFirst()
	{
		if(isEmpty())
			return null;
		E answer = head.getElement();
		head = head.getNext();
		size--;
		if(size==0)
			tail=null;
		return answer;
	}
	public MyLinkedList<E> union(MyLinkedList<E> a)
	{
		Node<E> pointer=this.head;
		MyLinkedList<E> ans = new MyLinkedList<E>();
		while(pointer!=null)
		{
			ans.addLast(pointer.getElement());
			pointer=pointer.getNext();
		}
		pointer=a.gethead();
		while(pointer!=null)
		{
			ans.addLast(pointer.getElement());
			pointer=pointer.getNext();
		}
		return ans;
	}
	public MyLinkedList<E> intersection(MyLinkedList<E> a)
	{
		Node<E> pointer=a.head;
		MyLinkedList<E> ans = new MyLinkedList<E>();
		while(pointer!=null)
		{
			if(this.isMember(pointer.getElement()))
				ans.addLast(pointer.getElement());
			pointer=pointer.getNext();
		}
		return ans;
	}
}
