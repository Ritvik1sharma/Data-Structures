public class Position
{
	private PageEntry page;
	private int wordposition;
	Position(PageEntry p, int wordIndex)
	{
		page=p;
		wordposition=wordIndex;
	}
	public PageEntry getPageEntry()
	{
		return page;
	}
	public int getWordIndex()
	{
		return wordposition;
	}	
}
