public class Mymobilephoneset{
	mobilephone root;
	public int size;
	private Myset mine=new Myset();
	public void MymobilePhoneSet()
	{
		root=null;
		size=0;
		return;
	}
	public Boolean IsEmpty()
	{
		return this.mine.IsEmpty();
	}
	public mobilephone getroot()
	{
		return (mobilephone) mine.getroot().getelement();
	}
	public Boolean IsMember(mobilephone a)
	{
		return mine.IsMember((Object) a);
	}
	public void Insert(mobilephone a)
	{
		mine.Insert((Object) a);
		return;
	}
	public void Delete(mobilephone a)
	{
		mine.Delete(a);
		return;
	}
	public Mymobilephoneset Union(Mymobilephoneset a){
		Mymobilephoneset x = new Mymobilephoneset();
		x.mine = mine.Union(a.mine);
		return x;
	}
	public Mymobilephoneset Intersection(Mymobilephoneset a){
		Mymobilephoneset x = new Mymobilephoneset();
		x.mine = mine.Intersection(a.mine);
		return x;
	}
	public mobilephone finder(int a)
	{
		mobilephone thisnode=this.root;
		while(thisnode!=null)
		{
			if(thisnode.getelement()==a)
				return thisnode;
			thisnode=thisnode.getnextmobile();
		}
		return null;
	}
}