public class mobilephone
{
	private int mobile;
	private mobilephone nextmobile;
	private boolean switch_val;
	Exchange base_station=new Exchange();
	public mobilephone(int a)
	{
		mobile=a;
		switch_val=true;
	}
	/*public mobilephone(int a, mobilephone next)
	{
		mobile=a;
		nextmobile=next;
		size++;
		switch_val=true;
	}*/
	public int getelement()
	{
		return mobile;
	}
	public Boolean status()
	{
		return switch_val;
	}
	public void switchOn()
	{
		switch_val=true;
	}
	public void switchOff()
	{
		switch_val=false;
	}
	mobilephone getnextmobile()
	{
		return nextmobile;
	}
	void setnextnode(mobilephone m)
	{
		this.nextmobile=m;
		return;
	}
	public Exchange location()
	{
		return base_station;
	}
	public void setlocation(Exchange a)
	{
		base_station=a;
	}
}