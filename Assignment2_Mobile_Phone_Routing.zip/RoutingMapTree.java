public class RoutingMapTree{
	Exchange root;
	public void sethead(Exchange a)
	{
		root=a;
		return;
	}
	public void RoutingMapTree()
	{
		Exchange a=new Exchange();
		a.setexchangeid(0);
		root=a;
		return;
	}

	public void switchOn(mobilephone a, Exchange b)
	{
		//////////////////////////////
		if(a.status()==false)
			return;
		Exchange ans=b;
		while(ans!=null)
		{
			ans.residentSet().Insert(a);
			ans=ans.Exchangeparent();
		}
		a.switchOn();
		//add in the exchange or finding the exchange is required........
		// set its base as exchange b................................................
	}
	public Exchange finder(int a)
	{
		if(root==null)
		{
			return null;
		}
		if(root.Exchangeid()==a)
		{
			return root;
		}
		Exchange ans;
		for(int i=0; i< this.root.numChildren(); i++)
		{
			ans=this.root.subtree(i).finder(a);
			if(ans!=null)
				return ans; 
		}
		return null;
	}
	public void switchOff(mobilephone a)
	{
		a.switchOff();
		Exchange base= a.location();
		while(base!=null)
		{
			try{
				base.residentSet().Delete(a);
			}
			catch(NullPointerException e)
			{
				System.out.println("num not found");
			}
			base=base.Exchangeparent();
		}
		return;
	}
	public Boolean Containsnode(Exchange a){
		if(root==null)
		{
			return false;
		}
		if(root==a)
		{
			return true;
		}
		for(int i=0;i<this.root.numChildren(); i++)
		{
			if(this.root.subtree(i).Containsnode(a)==true)
				return true; 
		}
		return false;
	}
	int getnumber(String actionMessage, int a)
	{ 
		int i;
		for(i=a; i<actionMessage.length(); i++)
		{
			if(actionMessage.charAt(i)==' ')
				break;
		}
		int end=i;
		return Integer.parseInt(actionMessage.substring(a, end));
	}
	public void performAction(String actionMessage) {
		if(actionMessage.charAt(0)=='a')
		{
			int a=getnumber(actionMessage, 12);
			int j=1;
			int i;
			for(i=12; i<actionMessage.length(); i++)
			{
				if(actionMessage.charAt(i)==' ')
				{
					break;
				}
			}
			int b=getnumber(actionMessage, (i+1));
			//////////////////////////////////////////
			
			
				Exchange a_base=this.finder(a);
				Exchange b_base=new Exchange();
				b_base.setexchangeid(b);
				a_base.children.Insert(b_base);
				b_base.Setparent(a_base);
			
		}
		if(actionMessage.charAt(0)=='s')
		{
			if(actionMessage.charAt(7)=='n')
			{
				int a=getnumber(actionMessage, 15);
				int j=1;
				int i;
				for(i=15; i<actionMessage.length(); i++)
				{
					if(actionMessage.charAt(i)==' ')
						break;
				}
				int b=getnumber(actionMessage, i+1);
				if(this.finder(a)==null)
		/////
				if(this.root.residentSet().finder(a)==null)
				{
					mobilephone a_num=new mobilephone(a);
					//a_num.switchOn();
					//a_num.base=
					Exchange b_base=this.finder(b);
					this.switchOn(a_num, b_base);
					a_num.setlocation(b_base);
				}
				else
				{
					mobilephone a_num=this.root.residentSet().finder(a);
					Exchange b_base=this.finder(b);
					this.switchOn(a_num, b_base);
				}
			}
			if(actionMessage.charAt(7)=='f')
			{
				int a=getnumber(actionMessage, 15);
				//////////////////
				this.switchOff(this.root.residentSet().finder(a));		
			}

		}
		if(actionMessage.charAt(0)=='q')
		{
			if(actionMessage.charAt(5)=='N')
			{
				int a_num=getnumber(actionMessage, 12);
				Exchange a=this.finder(a_num);
				int j=1;
				int i;
				for(i=15; i<actionMessage.length(); i++)
				{
					if(actionMessage.charAt(i)==' ')
						break;
				}
				int b=getnumber(actionMessage, i+1);
				System.out.println(a.child(b).Exchangeid());
			}
			if(actionMessage.charAt(5)=='M')
			{
				int a_num=getnumber(actionMessage, 12);
				Exchange a=this.finder(a_num);
				mobilephone point=a.residentSet().getroot();
				while(point!=null)
				{
					System.out.println(point.getelement());
					point=point.getnextmobile();
				}
			}
		}
		//System.out.println(actionMessage);	
	}
}
