public class Myset{
	node root;
	int size;
	public void Myset()
	{
		root=null;
		size=0;
		return;
	}
	public Boolean IsEmpty()
	{
		if(root==null)
		{
			return true;
		}
		else return false;
	}
	public Boolean IsMember(Object a)
	{
		node thisnode=this.root;
		while(thisnode!=null)
		{
			if(thisnode.getelement()==a)
				return true;
			thisnode=thisnode.getnextnode();
		}
		return false;
	}
	public void Insert(Object a)
	{	
		node newnode = new node();
		newnode.setelement(a);
		newnode.setnextnode(null);
		node point=this.root;
		if(point==null)
		{
			this.root=newnode;
			this.size++;
			return;
		}
		while(point.getnextnode()!=null)
		{
			point=point.getnextnode();
		}
		point.setnextnode(newnode);
		this.size++;
		return;
	}
	public void Delete(Object a)
	{
		node curr=this.root;
		node prev=null;          
		if(curr.getelement()==a)
		{
			this.root=this.root.getnextnode();
			this.size--;
			return;
		}
		while(curr!=null)
		{
			if(curr.getelement()==a)
			{
				prev.setnextnode(curr.getnextnode());
				this.size--;
				return;
			}
			prev=curr;
			curr=curr.getnextnode();
		}
		throw new NullPointerException("Element not found");

	}
	public Myset Union(Myset a)
	{
		Myset a1 = new Myset();
		node point=this.root;
		while(point!=null)
		{
			a1.Insert(point.getelement());
			point=point.getnextnode();
		}
		point=a.root;
		while(point!=null)
		{
			a1.Insert(point.getelement());
			point=point.getnextnode();
		}
		return a1;
	}
	public Myset Intersection(Myset a){
		Myset a1 = new Myset();
		node point=a.root;
		while(point!=null)
		{
			if(this.IsMember(point.getelement())==true)
				a1.Insert(point.getelement());
			point=point.getnextnode();
		}
		return a1;
	}
	public node getroot()
	{
		return this.root;
	}

}


class node
	{
		private Object node_data;
		private node next;
//		private boolean switch_val;
		/*public void node(Object a)
		{
			node_data=a;
			//switch_val=true;
		}*/
		public void setelement(Object a)
		{
			this.node_data=a;
		}
		public void node(Object a, node next)
		{
			node_data=a;
			next=next;

		}
		public Object getelement()
		{
			return node_data;
		}
		node getnext()
		{
			return next;
		}
		void setnextnode(node m)
		{
			this.next=m;
			return;
		}
		node getnextnode()
		{
			return this.next;
		}
//– public Exchange location()
	}
