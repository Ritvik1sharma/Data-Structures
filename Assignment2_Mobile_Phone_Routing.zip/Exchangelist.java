class Exchangenode{
	private Exchange Exchangeval;
	private Exchangenode next;
	void Exchangenode(Exchange a)
	{
		Exchangeval=a;
		next=null;
	}
	Exchangenode getnextnode(){
		return this.next;
	}
	Exchange getid(){
		return this.Exchangeval;
	}
	void setnextnode(Exchangenode a)
	{
		if(a==null)
		{
			this.next=null;
		}
		Exchangenode point=this.next;
		this.next=a;
		a.next=point;
	}
	void setexchange(Exchange a)
	{
		this.Exchangeval=a;
	}
	void setid(int a)
	{
		this.Exchangeval.setexchangeid(a);
		return;
	}
}
public class Exchangelist{
	private Exchangenode root;
	private int size=0;
	public int sizeof()
	{
		return size;
	}
	public Exchangenode gethead()
	{
		return root;
	}
	public void sethead(Exchangenode a){
		root=a;
		return;
	}
	public void Exchangelist()
	{
		root=null;
		size=0;
		return;
	}
	public Boolean IsEmpty()
	{
		if(size==0)
		{
			return true;
		}
		else return false;
	}
	public Boolean IsMember(Exchange a)
	{
		Exchangenode thisnode=this.root;
		while(thisnode!=null)
		{
			if(thisnode.getid()==a)
				return true;
			thisnode=thisnode.getnextnode();
		}
		return false;
	}
	public void Insert(Exchange a)
	{	
		if(this.IsMember(a)==true)
			return;
		Exchangenode newnode= new Exchangenode();
		newnode.setexchange(a);
		newnode.setnextnode(null);
		Exchangenode point;
		point=this.root;
		if(point==null)
		{
			this.root=newnode;
			this.size++;
			return;
		}
		while(point.getnextnode()!=null)
		{
			point=point.getnextnode();
		}
		point.setnextnode(newnode);
		this.size++;
		return;
	}
	public void Delete(Exchange a)
	{
		Exchangenode curr=this.root;
		Exchangenode prev=null;
		if(curr.getid()==a)
		{
			this.root=this.root.getnextnode();
			this.size--;
			return;
		}
		while(curr!=null)
		{
			if(curr.getid()==a)
			{
				prev.setnextnode(curr.getnextnode());
				this.size--;
				return;
			}
			prev=curr;
			curr=curr.getnextnode();
		}
		return;
	}
	public Exchangelist Union(Exchangelist a){
		Exchangelist a1 = new Exchangelist();
		Exchangenode point=this.root;
		while(point!=null)
		{
			a1.Insert(point.getid());
			point=point.getnextnode();
		}
		point=a.root;
		while(point!=null)
		{
			a1.Insert(point.getid());
			point=point.getnextnode();
		}
		return a1;
	}
	public Exchangelist Intersection(Exchangelist a){
		Exchangelist a1 = new Exchangelist();
		Exchangenode point=a.root;
		while(a!=null)
		{
			if(this.IsMember(point.getid())==true)
				a1.Insert(point.getid());
			point=point.getnextnode();
		}
		return a1;
	}
}
