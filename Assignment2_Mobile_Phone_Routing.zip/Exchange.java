public class Exchange{
	int exchangeid;
	Exchange parent;
	Exchangelist children = new Exchangelist();
	Mymobilephoneset residentSet= new Mymobilephoneset();
	public void setexchangeid(int a)
	{
		exchangeid=a;
		return;
	}
	public int Exchangeid()
	{
		return exchangeid;
	}
	public void Exchange()
	{
		exchangeid=0;
		return;
	}
	public void Exchange(int a)
	{
		exchangeid=a;
		//this.parent=null;
//		this.children.sethead()=null;
//		residentSet=null;
	}
	public void Setparent(Exchange a)
	{
		this.parent=a;
		return;
	}
	public Exchange Exchangeparent(){
		return parent;
	}
	public int numChildren()
	{
		return this.children.sizeof();
	}
	public Exchange child(int i)
	{
		Exchangenode point=this.children.gethead();
		while(i>0)
		{
			i--;
			point=point.getnextnode();
		}
		return point.getid();		
	}
	public Boolean isRoot()
	{
		if(this.parent==null)
		{
			return true;
		}
		else return false;
	}
	public RoutingMapTree subtree(int i)
	{
		RoutingMapTree subtree = new RoutingMapTree();
		Exchange point;
		subtree.sethead(this.child(i));
		return subtree;
	}
	public Mymobilephoneset residentSet()
	{
		return residentSet;
	}
}